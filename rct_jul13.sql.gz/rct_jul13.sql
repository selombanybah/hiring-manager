-- Adminer 3.1.0 MySQL dump

SET NAMES utf8;
SET foreign_key_checks = 0;
SET time_zone = 'America/Los_Angeles';
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE TABLE `rct_applicant` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vacancy_id` int(11) NOT NULL,
  `application_date` date NOT NULL,
  `salutation` varchar(100) DEFAULT NULL,
  `name_first` varchar(100) NOT NULL,
  `name_middle` varchar(100) DEFAULT NULL,
  `name_last` varchar(100) DEFAULT NULL,
  `sex` char(1) DEFAULT NULL,
  `d_o_b` date DEFAULT NULL,
  `nationality` varchar(20) NOT NULL DEFAULT 'Indian',
  `marital_status` char(2) NOT NULL DEFAULT 'M',
  `edu_qualification` text,
  `work_experience` varchar(50) DEFAULT NULL,
  `languages_known` varchar(100) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `country_name` varchar(30) NOT NULL DEFAULT '',
  `state_name` varchar(30) NOT NULL DEFAULT '',
  `city_name` varchar(30) NOT NULL DEFAULT '',
  `zip` int(6) DEFAULT '0',
  `hobby` varchar(20) DEFAULT NULL,
  `contact_no` varchar(20) DEFAULT NULL,
  `call_time` varchar(100) DEFAULT NULL,
  `email_id` varchar(50) NOT NULL,
  `alternate_email_id` varchar(200) DEFAULT NULL,
  `resume` varchar(50) DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  `application_status` decimal(4,2) NOT NULL,
  `alloted_to` varchar(15) DEFAULT NULL,
  `prioritize` tinyint(1) DEFAULT NULL,
  `assigned_to` varchar(15) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_resume_vacancy` (`vacancy_id`),
  CONSTRAINT `rct_applicant_ibfk_1` FOREIGN KEY (`vacancy_id`) REFERENCES `rct_vacancy` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `rct_applicant` (`id`, `vacancy_id`, `application_date`, `salutation`, `name_first`, `name_middle`, `name_last`, `sex`, `d_o_b`, `nationality`, `marital_status`, `edu_qualification`, `work_experience`, `languages_known`, `address`, `country_name`, `state_name`, `city_name`, `zip`, `hobby`, `contact_no`, `call_time`, `email_id`, `alternate_email_id`, `resume`, `image`, `application_status`, `alloted_to`, `prioritize`, `assigned_to`, `user_id`, `created_date`, `timestamp`) VALUES
(2,	1,	'0000-00-00',	'1',	'viral',	'',	'',	'f',	'0000-00-00',	'Indian',	'',	'dsd',	'',	'',	'sd',	'sds',	'sdas',	'asda',	0,	'',	'9995075589',	'',	'',	'',	'',	'',	1.00,	'',	NULL,	'',	0,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(4,	1,	'0000-00-00',	'0',	'jhf',	'g',	'gj',	'',	'0000-00-00',	'Indian',	'',	'jkgj',	'',	'',	'hg',	'jhg',	'jhg',	'jhg',	0,	'',	'9995075589',	'',	'',	'',	'',	'Winter.jpg',	0.00,	'',	NULL,	'',	0,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00');

CREATE TABLE `rct_general_questions` (
  `question_id` int(5) NOT NULL AUTO_INCREMENT,
  `question_text` text NOT NULL,
  `display_order` tinyint(2) DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` varchar(50) NOT NULL DEFAULT '',
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`question_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `rct_general_questions` (`question_id`, `question_text`, `display_order`, `timestamp`, `user_id`, `created_date`) VALUES
(1,	'test question1 ',	1,	'2011-03-01 00:15:33',	'',	'0000-00-00 00:00:00'),
(2,	'question2??',	2,	'2011-03-04 03:26:29',	'',	'0000-00-00 00:00:00');

CREATE TABLE `rct_history` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `vacancy_id` varchar(10) DEFAULT NULL,
  `applicant_id` varchar(15) DEFAULT NULL,
  `interview_id` int(10) DEFAULT NULL,
  `status` decimal(4,2) DEFAULT NULL,
  `action` text,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `rct_history_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `rct_user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `rct_history` (`id`, `vacancy_id`, `applicant_id`, `interview_id`, `status`, `action`, `timestamp`, `user_id`, `created_date`) VALUES
(1,	'11',	NULL,	NULL,	NULL,	'Vacancy created',	'0000-00-00 00:00:00',	1,	'0000-00-00 00:00:00'),
(2,	'11',	NULL,	NULL,	NULL,	'No of positions modified',	'0000-00-00 00:00:00',	1,	'0000-00-00 00:00:00'),
(3,	NULL,	NULL,	NULL,	NULL,	'Is it still open ?',	'2011-07-05 22:41:18',	1,	'2011-07-05 22:41:18'),
(4,	'11',	NULL,	NULL,	NULL,	'is it still open ?',	'2011-07-05 22:43:40',	1,	'2011-07-05 22:43:40'),
(5,	'11',	NULL,	NULL,	NULL,	'I heard its over.',	'2011-07-06 02:21:49',	1,	'2011-07-06 02:21:49'),
(6,	'4',	NULL,	NULL,	NULL,	'We will have good applications for this one',	'2011-07-06 02:23:59',	1,	'2011-07-06 02:23:59');

CREATE TABLE `rct_mail_text` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `action` varchar(50) NOT NULL,
  `subject` text,
  `mail_text` text,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` varchar(50) NOT NULL,
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `rct_mail_text` (`id`, `action`, `subject`, `mail_text`, `timestamp`, `user_id`, `created_date`) VALUES
(1,	'Rejected',	'test',	'test mail',	'2011-03-01 00:28:47',	'',	'0000-00-00 00:00:00'),
(2,	'1',	'test',	'test mail',	'2011-03-01 00:34:04',	'',	'0000-00-00 00:00:00'),
(3,	'1',	'sorry',	'sorry',	'2011-03-04 03:25:39',	'',	'0000-00-00 00:00:00');

CREATE TABLE `rct_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  `firstname` varchar(128) NOT NULL,
  `lastname` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `profile` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `rct_user` (`id`, `username`, `password`, `firstname`, `lastname`, `email`, `profile`) VALUES
(1,	'admin',	'0192023a7bbd73250516f069df18b500',	'Admin',	'adminLast',	'shikhar.kr@gmail.com',	NULL);

CREATE TABLE `rct_vacancy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vacancy_code` varchar(10) NOT NULL,
  `emp_type` varchar(30) NOT NULL DEFAULT '',
  `designation` varchar(30) NOT NULL DEFAULT '',
  `department` varchar(100) DEFAULT NULL,
  `no_of_vacancy` int(10) DEFAULT NULL,
  `no_of_hiring` int(10) DEFAULT NULL,
  `edu_qualification` text,
  `age` int(3) DEFAULT NULL,
  `age_on` date DEFAULT NULL,
  `experience` float DEFAULT NULL,
  `min_salary` int(10) DEFAULT NULL,
  `max_salary` int(10) DEFAULT NULL,
  `description` text,
  `requirements` text,
  `last_date` date DEFAULT NULL,
  `active` enum('y','n') NOT NULL DEFAULT 'y',
  `log` text,
  `hiring_person` varchar(15) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vacancy_id` (`vacancy_code`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `rct_vacancy_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `rct_user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `rct_vacancy` (`id`, `vacancy_code`, `emp_type`, `designation`, `department`, `no_of_vacancy`, `no_of_hiring`, `edu_qualification`, `age`, `age_on`, `experience`, `min_salary`, `max_salary`, `description`, `requirements`, `last_date`, `active`, `log`, `hiring_person`, `user_id`, `created_date`, `modified_date`) VALUES
(1,	'1',	'Teacher',	'Lecturer',	'IT',	5,	NULL,	'',	0,	NULL,	NULL,	NULL,	NULL,	'',	'',	'0000-00-00',	'n',	'',	'',	1,	'2011-03-01 00:00:00',	'2011-07-05 23:28:35'),
(2,	'E01',	'Permanent',	'Tech writer',	'IT',	2,	NULL,	'Graduate',	30,	'0000-00-00',	3,	NULL,	NULL,	'',	'',	'0000-00-00',	'y',	'',	'',	1,	'2011-04-30 00:00:00',	'2011-07-05 23:34:30'),
(3,	'E02',	'Permanent',	'Tech writer senior',	'IT',	2,	NULL,	'',	0,	'0000-00-00',	NULL,	NULL,	NULL,	'',	'',	'0000-00-00',	'y',	'',	'',	1,	'2011-04-30 00:00:00',	'2011-07-05 23:34:38'),
(4,	'E03',	'Permanent',	'Tech writer junior',	'IT',	2,	NULL,	'',	0,	'0000-00-00',	NULL,	NULL,	NULL,	'',	'',	'0000-00-00',	'n',	'',	NULL,	1,	'0000-00-00 00:00:00',	'2011-07-05 23:34:44'),
(5,	'E04',	'Permanent',	'temporary',	'IT',	2,	1,	'',	0,	'0000-00-00',	NULL,	NULL,	NULL,	'',	'',	'0000-00-00',	'y',	'',	NULL,	1,	'0000-00-00 00:00:00',	'2011-07-05 23:10:01'),
(6,	'E05',	'Permanent',	'Tech writer junior',	'IT',	NULL,	NULL,	'',	0,	'0000-00-00',	NULL,	NULL,	NULL,	'',	'',	'0000-00-00',	'y',	'',	NULL,	1,	'0000-00-00 00:00:00',	'2011-07-05 23:10:01'),
(7,	'E06',	'Permanent',	'Tech writer junior',	'IT',	NULL,	NULL,	'',	0,	'0000-00-00',	NULL,	NULL,	NULL,	'',	'',	'0000-00-00',	'n',	'',	NULL,	1,	'0000-00-00 00:00:00',	'2011-07-05 23:10:01'),
(8,	'E08',	'Permanent',	's/w eng',	'',	NULL,	NULL,	'',	0,	'0000-00-00',	NULL,	NULL,	NULL,	'',	'',	'0000-00-00',	'y',	'',	NULL,	1,	'2011-05-01 00:46:07',	'2011-07-05 23:10:01'),
(9,	'E10',	'Permanent',	'Accountant',	'Accounts',	1,	NULL,	'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum',	30,	NULL,	2,	NULL,	NULL,	'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum',	'',	'0000-00-00',	'y',	NULL,	NULL,	1,	'2011-06-10 05:29:15',	'2011-06-10 05:28:51'),
(10,	'E07',	'Permanent',	's/w eng',	'IT',	2,	0,	'Btech(computer science)',	28,	NULL,	2,	NULL,	NULL,	'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum',	'',	NULL,	'y',	NULL,	NULL,	1,	'2011-06-10 06:14:21',	'2011-06-10 06:13:57'),
(11,	'E09',	'Permanent',	's/w eng',	'IT',	1,	0,	'BTech',	NULL,	NULL,	NULL,	NULL,	NULL,	'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum',	'',	NULL,	'y',	NULL,	NULL,	1,	'2011-06-10 06:16:09',	'2011-06-10 06:15:45');

-- 2011-07-13 06:11:43
